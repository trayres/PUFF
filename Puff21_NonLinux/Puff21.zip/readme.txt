
Puff 2.1
--------

For your information:

The subdirectory PROT\ on this disk contains an additional protected
mode version of Puff 2.1. However, this is in an experimental stage
and therefore should be considered a Beta version. Use at your own risk!

In contrast to the real mode version, the protected mode code is able
to access the whole memory space of the machine. This allows to analyze
bigger circuits or to calculate more points.


============================================================================

Zur Information:

Im Unterverzeichnis PROT\ ist auf dieser Diskette zus�tzlich
eine experimentelle Protected Mode Version von Puff 2.1 abgelegt,
die sich aber noch im Beta-Stadium befindet.

Die Protected Mode Version spricht im Gegensatz zur normalen
Version den gesamten Hauptspeicher des Rechners an und erlaubt es
so, gr��ere Schaltungen zu bearbeiten bzw. mehr Punkte bei
der Analyse zu berechnen.


============================================================================

Changelog:
  10/98  Applied patch to Borland compiler to fix runtime errors at
         startup on fast machines.


Andreas Gerstlauer
(andreas@musoftware.de)
